define([
    'FXReport/ReportUtility'
], function () {
    // load & initialize 
});